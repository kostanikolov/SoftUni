package pizza_calories;

public class PizzaConstants {
    public static final double BASE_CALORIES = 2;

    private PizzaConstants() {
    }
}
